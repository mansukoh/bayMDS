
# bayMDS

R package bayMDS for Bayesian Multidimensional Scaling and Choice of Dimension

## How to install bayMDS 

### 1. Installing packages from CRAN using R command

``` r
install.packages("bayMDS",dependencies=TRUE)
```


### 2. Installing packages from CRAN using Rstudio GUI

In menu, select  "Tools" -> "Install Packages.." 


1. type **bayMDS** under **packages (separate multiple with space or comma)**

2. check **Install dependencies**

3. click **Install** button

